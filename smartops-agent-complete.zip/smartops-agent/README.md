# SmartOps Agent

SmartOps Agent 是一个面向 Spring Boot 后端项目的智能故障诊断与自动修复建议平台。

它不是普通的 CRUD 项目，而是把“Java 后端真实开发里的排查能力”产品化：

- 自动扫描 Spring Boot 项目源码
- 识别 Controller -> Service -> Mapper/Repository -> DB/Redis/第三方接口 的业务链路
- 分析 401 Unauthorized、SQL 报错、Redis 连接失败、NPE、Bean 启动失败等日志
- 检查 Spring Security、JWT、密码加密、退出登录、放行规则等安全配置
- 分析慢 SQL 的常见问题：SELECT *、LIKE 前置通配符、深分页、ORDER BY、缺少 WHERE
- 输出 Markdown 分析报告、问题清单、修复建议和代码片段

## 技术栈

- Java 17
- Spring Boot 3
- Spring MVC
- Maven
- Actuator
- 原生 HTML + JavaScript 管理页

## 项目结构

```text
smartops-agent
├── src/main/java/com/example/smartops
│   ├── controller
│   │   └── AnalysisController.java
│   ├── model
│   │   ├── AnalysisRequest.java
│   │   ├── AnalysisResponse.java
│   │   ├── EndpointChain.java
│   │   ├── ChainStep.java
│   │   ├── Finding.java
│   │   ├── Suggestion.java
│   │   └── Severity.java
│   ├── service
│   │   ├── AnalysisOrchestrator.java
│   │   ├── SourceCodeScanner.java
│   │   ├── ChainTraceAgent.java
│   │   ├── LogAnalysisAgent.java
│   │   ├── SecurityDiagnosisAgent.java
│   │   ├── SqlOptimizeAgent.java
│   │   ├── RepairSuggestionAgent.java
│   │   ├── ReportRenderer.java
│   │   └── ProjectZipService.java
│   └── SmartOpsAgentApplication.java
└── src/main/resources/static/index.html
```

## Agent 分工

### 1. SourceCodeScanner

负责扫描源码，解析 Java 类、字段、方法、注解、行号。

### 2. ChainTraceAgent

负责从 Controller 接口入口开始，追踪到 Service、Mapper/Repository、Redis、JWT、第三方接口等调用点，形成业务链路。

### 3. LogAnalysisAgent

负责分析运行日志，识别常见故障：

- 401 Unauthorized
- 404 路径错误
- SQLSyntaxErrorException
- RedisConnectionFailureException
- NullPointerException
- BeanCreationException
- 端口占用

### 4. SecurityDiagnosisAgent

负责扫描安全配置：

- 是否有 SecurityFilterChain
- JWT 是否配置 STATELESS
- Authorization 是否统一 Bearer 格式
- 是否使用 PasswordEncoder / BCrypt / Argon2
- logout 是否只是前端删除 token
- 登录接口是否可能未放行

### 5. SqlOptimizeAgent

负责分析慢 SQL：

- SELECT *
- LIKE '%xxx%'
- 深分页 OFFSET
- ORDER BY 无 LIMIT
- OR 条件影响索引
- 无 WHERE 全表扫描

### 6. RepairSuggestionAgent

负责把诊断结果转换成修复建议和代码片段。

## 启动项目

```bash
mvn spring-boot:run
```

启动后访问：

```text
http://localhost:8088
```

健康检查：

```bash
curl http://localhost:8088/api/analysis/health
```

## 使用方式一：网页上传 zip

1. 把你的 Spring Boot 项目压缩成 zip
2. 启动 SmartOps Agent
3. 打开 http://localhost:8088
4. 上传 zip
5. 粘贴日志和慢 SQL
6. 点击“开始分析”

## 使用方式二：直接调用 JSON 接口

```bash
curl -X POST http://localhost:8088/api/analysis/analyze-text \
  -H "Content-Type: application/json" \
  -d @examples/sample-request.json
```

## 使用方式三：上传 ZIP 接口

```bash
curl -X POST http://localhost:8088/api/analysis/upload-zip \
  -F "file=@your-springboot-project.zip" \
  -F "projectName=music-system" \
  -F "logText=401 Unauthorized" \
  -F "slowSql=select * from song where name like '%jay%';"
```

## 可继续升级的方向

这个版本是可运行的 MVP。后续可以继续升级：

1. 接入 JavaParser，替换当前正则扫描，提高源码解析准确率。
2. 接入 OpenTelemetry，采集真实线上接口链路。
3. 接入 MySQL EXPLAIN，自动读取执行计划。
4. 接入 Redis，做 JWT 黑名单、缓存一致性检测。
5. 接入 Git，自动生成修复分支和 PR。
6. 接入大模型 API，把规则诊断升级成自然语言推理和代码补丁生成。
7. 增加登录、权限、SQL、缓存的自动化测试生成。

## 面试讲法

这个项目可以这样介绍：

> 我做了一个面向 Spring Boot 系统的 SmartOps Agent。它可以上传一个 Java 项目 zip 和运行日志，然后自动扫描 Controller、Service、Mapper、Redis、JWT 等代码结构，还原接口业务链路，并结合日志诊断 401、SQL、Redis、NPE、Bean 启动失败等问题。系统内部采用多 Agent 协作：链路追踪 Agent 负责源码调用链分析，日志 Agent 负责故障归因，安全 Agent 负责 Spring Security 和 JWT 配置检查，SQL Agent 负责慢查询优化建议，修复 Agent 最后生成修复方案和代码片段。这个项目重点不是写 CRUD，而是把真实后端排查问题的流程产品化。
