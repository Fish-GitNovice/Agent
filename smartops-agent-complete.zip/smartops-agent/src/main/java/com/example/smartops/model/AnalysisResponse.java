package com.example.smartops.model;

import java.util.List;

public record AnalysisResponse(
        String projectName,
        List<EndpointChain> endpointChains,
        List<Finding> findings,
        List<Suggestion> suggestions,
        String markdownReport
) {
}
