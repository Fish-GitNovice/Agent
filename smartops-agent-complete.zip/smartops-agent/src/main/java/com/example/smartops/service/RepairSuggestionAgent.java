package com.example.smartops.service;

import com.example.smartops.model.Finding;
import com.example.smartops.model.Suggestion;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class RepairSuggestionAgent {
    public List<Suggestion> generate(List<Finding> findings) {
        List<Suggestion> suggestions = new ArrayList<>();
        if (findings == null) {
            return suggestions;
        }
        for (Finding finding : findings) {
            switch (finding.category()) {
                case "Security" -> addSecuritySuggestion(finding, suggestions);
                case "SQL" -> addSqlSuggestion(finding, suggestions);
                case "Redis" -> suggestions.add(new Suggestion(
                        "检查 Redis 运行状态和配置",
                        "application.yml / Docker",
                        "确认 Redis 容器已启动、端口映射正确，并检查 host、port、password。",
                        "docker ps\nredis-cli -h 127.0.0.1 -p 6379 ping"));
                case "Spring" -> suggestions.add(new Suggestion(
                        "按 caused by 逆向定位 Bean 创建失败",
                        "Spring Boot 启动日志",
                        "先看异常最底部 caused by，再回到对应配置类或 Bean。",
                        "// 常见检查项\n// 1. @Service / @Component 是否被扫描\n// 2. @MapperScan 是否配置\n// 3. application.yml 是否缺少必要配置\n// 4. pom.xml 是否缺依赖"));
                default -> {
                    if (finding.recommendation() != null && !finding.recommendation().isBlank()) {
                        suggestions.add(new Suggestion(
                                finding.title(),
                                finding.category(),
                                finding.recommendation(),
                                ""));
                    }
                }
            }
        }
        return suggestions;
    }

    private void addSecuritySuggestion(Finding finding, List<Suggestion> suggestions) {
        if (finding.title().contains("401") || finding.title().contains("JWT") || finding.title().contains("放行")) {
            suggestions.add(new Suggestion(
                    "补全 Spring Security + JWT 核心配置",
                    "SecurityConfig.java",
                    "放行登录接口，其他接口认证；JWT 项目配置无状态 Session，并把 JWT Filter 放到 UsernamePasswordAuthenticationFilter 前。",
                    "@Bean\nSecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {\n    return http\n        .csrf(csrf -> csrf.disable())\n        .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))\n        .authorizeHttpRequests(auth -> auth\n            .requestMatchers(\"/api/auth/login\", \"/api/auth/register\").permitAll()\n            .anyRequest().authenticated()\n        )\n        .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class)\n        .build();\n}"));
        }
        if (finding.title().contains("密码")) {
            suggestions.add(new Suggestion(
                    "统一密码加密和校验方式",
                    "AuthService.java",
                    "注册时 encode，登录时 matches，禁止明文比较。",
                    "String encoded = passwordEncoder.encode(rawPassword);\nboolean ok = passwordEncoder.matches(loginPassword, user.getPassword());"));
        }
        if (finding.title().contains("退出")) {
            suggestions.add(new Suggestion(
                    "实现 JWT 服务端退出黑名单",
                    "AuthService.logout",
                    "退出时把当前 token 写入 Redis 黑名单，过期时间等于 token 剩余有效期。",
                    "String token = resolveBearerToken(request);\nlong ttl = jwtService.remainingMillis(token);\nstringRedisTemplate.opsForValue().set(\"jwt:blacklist:\" + token, \"1\", ttl, TimeUnit.MILLISECONDS);"));
        }
    }

    private void addSqlSuggestion(Finding finding, List<Suggestion> suggestions) {
        suggestions.add(new Suggestion(
                "为慢 SQL 补充 EXPLAIN 和索引验证",
                "MySQL",
                "不要只凭感觉建索引，先用 EXPLAIN 看 type、key、rows、Extra。",
                "EXPLAIN " + safeSql(finding.evidence()) + ";\n-- 重点看 type 是否为 ALL、key 是否为空、rows 是否过大、Extra 是否出现 Using filesort"));
    }

    private String safeSql(String sql) {
        if (sql == null || sql.isBlank()) {
            return "SELECT ...";
        }
        String oneLine = sql.replaceAll("\\s+", " ").trim();
        return oneLine.endsWith(";") ? oneLine.substring(0, oneLine.length() - 1) : oneLine;
    }
}
