package com.example.smartops.service;

import java.util.Locale;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MappingParser {
    private static final Pattern STRING_VALUE_PATTERN = Pattern.compile("\\(\\s*\\{?\\s*\"([^\"]*)\"");
    private static final Pattern VALUE_PATTERN = Pattern.compile("(?:value|path)\\s*=\\s*(?:\\{\\s*)?\"([^\"]*)\"");
    private static final Pattern METHOD_PATTERN = Pattern.compile("method\\s*=\\s*RequestMethod\\.([A-Z]+)");

    private MappingParser() {
    }

    public static Optional<Mapping> parse(String annotations) {
        if (annotations == null || annotations.isBlank()) {
            return Optional.empty();
        }
        if (annotations.contains("@GetMapping")) {
            return Optional.of(new Mapping("GET", extractPath(annotations, "GetMapping")));
        }
        if (annotations.contains("@PostMapping")) {
            return Optional.of(new Mapping("POST", extractPath(annotations, "PostMapping")));
        }
        if (annotations.contains("@PutMapping")) {
            return Optional.of(new Mapping("PUT", extractPath(annotations, "PutMapping")));
        }
        if (annotations.contains("@DeleteMapping")) {
            return Optional.of(new Mapping("DELETE", extractPath(annotations, "DeleteMapping")));
        }
        if (annotations.contains("@PatchMapping")) {
            return Optional.of(new Mapping("PATCH", extractPath(annotations, "PatchMapping")));
        }
        if (annotations.contains("@RequestMapping")) {
            String method = "REQUEST";
            Matcher methodMatcher = METHOD_PATTERN.matcher(annotations);
            if (methodMatcher.find()) {
                method = methodMatcher.group(1).toUpperCase(Locale.ROOT);
            }
            return Optional.of(new Mapping(method, extractPath(annotations, "RequestMapping")));
        }
        return Optional.empty();
    }

    public static String classLevelPath(String annotations) {
        if (annotations == null || !annotations.contains("@RequestMapping")) {
            return "";
        }
        return extractPath(annotations, "RequestMapping");
    }

    private static String extractPath(String annotations, String mappingName) {
        int index = annotations.indexOf("@" + mappingName);
        if (index < 0) {
            return "";
        }
        int end = annotations.indexOf("\n", index);
        String mappingAnnotation = end >= 0 ? annotations.substring(index, end) : annotations.substring(index);

        Matcher valueMatcher = VALUE_PATTERN.matcher(mappingAnnotation);
        if (valueMatcher.find()) {
            return valueMatcher.group(1);
        }
        Matcher stringMatcher = STRING_VALUE_PATTERN.matcher(mappingAnnotation);
        if (stringMatcher.find()) {
            return stringMatcher.group(1);
        }
        return "";
    }

    public static String joinPath(String base, String child) {
        String normalizedBase = base == null ? "" : base.trim();
        String normalizedChild = child == null ? "" : child.trim();
        if (normalizedBase.isBlank() && normalizedChild.isBlank()) {
            return "/";
        }
        String joined = ("/" + normalizedBase + "/" + normalizedChild).replaceAll("/+", "/");
        if (joined.length() > 1 && joined.endsWith("/")) {
            joined = joined.substring(0, joined.length() - 1);
        }
        return joined;
    }

    public record Mapping(String method, String path) {
    }
}
