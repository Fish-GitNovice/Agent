package com.example.smartops.service;

import java.util.LinkedHashMap;
import java.util.Map;

public class JavaClassInfo {
    private final String path;
    private final String packageName;
    private final String className;
    private final String content;
    private final String annotations;
    private final Map<String, String> fields = new LinkedHashMap<>();
    private final Map<String, JavaMethodInfo> methods = new LinkedHashMap<>();

    public JavaClassInfo(String path, String packageName, String className, String content, String annotations) {
        this.path = path;
        this.packageName = packageName;
        this.className = className;
        this.content = content;
        this.annotations = annotations;
    }

    public String path() { return path; }
    public String packageName() { return packageName; }
    public String className() { return className; }
    public String content() { return content; }
    public String annotations() { return annotations; }
    public Map<String, String> fields() { return fields; }
    public Map<String, JavaMethodInfo> methods() { return methods; }

    public boolean hasAnnotation(String annotationName) {
        return annotations != null && annotations.contains("@" + annotationName);
    }
}
