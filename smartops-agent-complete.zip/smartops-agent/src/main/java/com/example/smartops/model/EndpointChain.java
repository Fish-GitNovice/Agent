package com.example.smartops.model;

import java.util.List;

public record EndpointChain(
        String httpMethod,
        String path,
        String controllerClass,
        String controllerMethod,
        List<ChainStep> steps
) {
}
