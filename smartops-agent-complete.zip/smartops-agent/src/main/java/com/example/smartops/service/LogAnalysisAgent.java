package com.example.smartops.service;

import com.example.smartops.model.Finding;
import com.example.smartops.model.Severity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Component
public class LogAnalysisAgent {
    public List<Finding> analyze(String logText) {
        List<Finding> findings = new ArrayList<>();
        if (logText == null || logText.isBlank()) {
            findings.add(new Finding(
                    Severity.INFO,
                    "Log",
                    "未提供运行日志",
                    "logText 为空",
                    "当前只能基于源码做静态分析，无法判断真实运行时异常。",
                    "建议复制控制台报错、接口响应、慢 SQL 日志一起提交。"));
            return findings;
        }

        String text = logText;
        String lower = text.toLowerCase(Locale.ROOT);

        if (containsAny(text, "401 Unauthorized", "Full authentication is required", "AccessDeniedException", "BadCredentialsException")) {
            findings.add(new Finding(
                    Severity.HIGH,
                    "Security",
                    "接口出现 401 / 鉴权失败",
                    extractEvidence(text, "401", "Unauthorized", "AccessDeniedException", "BadCredentialsException"),
                    "常见原因是前端没有按 Bearer Token 格式传 Authorization、SecurityConfig 未放行登录接口、JWT 解析失败、Redis token 已过期或密码校验不一致。",
                    "先检查请求头是否为 Authorization: Bearer <token>，再检查 SecurityConfig 的 requestMatchers、JWT filter 和 token 过期时间。"));
        }

        if (containsAny(text, "No static resource", "404", "NoHandlerFoundException")) {
            findings.add(new Finding(
                    Severity.MEDIUM,
                    "Route",
                    "接口路径可能不匹配",
                    extractEvidence(text, "404", "No static resource", "NoHandlerFoundException"),
                    "前端请求路径、Controller 的 @RequestMapping、项目 context-path 三者可能不一致。",
                    "用接口链路扫描结果对照前端真实请求 URL，确认 HTTP 方法和路径完全一致。"));
        }

        if (containsAny(text, "SQLSyntaxErrorException", "BadSqlGrammarException", "Unknown column", "Table", "doesn't exist")) {
            findings.add(new Finding(
                    Severity.HIGH,
                    "SQL",
                    "SQL 语法或表字段错误",
                    extractEvidence(text, "SQLSyntaxErrorException", "BadSqlGrammarException", "Unknown column", "doesn't exist"),
                    "数据库表结构与代码里的 Entity、Mapper XML 或 SQL 字段不一致。",
                    "检查数据库表名、字段名、驼峰下划线映射，以及 MyBatis XML / JPA Entity。"));
        }

        if (containsAny(text, "Duplicate entry", "DataIntegrityViolationException", "ConstraintViolationException")) {
            findings.add(new Finding(
                    Severity.MEDIUM,
                    "Database",
                    "唯一索引或约束冲突",
                    extractEvidence(text, "Duplicate entry", "DataIntegrityViolationException", "ConstraintViolationException"),
                    "插入数据时违反了唯一索引、非空约束或外键约束。",
                    "在写入前做唯一性校验，并给前端返回明确业务错误，例如“用户名已存在”。"));
        }

        if (containsAny(text, "RedisConnectionFailureException", "Unable to connect to Redis", "Connection refused", "lettuce")) {
            findings.add(new Finding(
                    Severity.HIGH,
                    "Redis",
                    "Redis 连接失败",
                    extractEvidence(text, "RedisConnectionFailureException", "Unable to connect", "Connection refused", "lettuce"),
                    "Redis 服务未启动、端口配置错误、密码错误或 Docker 端口未映射。",
                    "检查 spring.data.redis.host/port/password，并用 redis-cli 或 Docker ps 验证 Redis 是否可连接。"));
        }

        if (containsAny(text, "NullPointerException")) {
            findings.add(new Finding(
                    Severity.HIGH,
                    "Runtime",
                    "空指针异常",
                    extractEvidence(text, "NullPointerException"),
                    "某个对象为 null 但代码继续调用它的方法或属性。",
                    "根据堆栈第一行定位业务代码，重点检查查询结果是否为空、DTO 字段是否为空、依赖是否注入成功。"));
        }

        if (containsAny(text, "BeanCreationException", "UnsatisfiedDependencyException", "No qualifying bean", "Failed to configure")) {
            findings.add(new Finding(
                    Severity.HIGH,
                    "Spring",
                    "Spring Bean 启动失败",
                    extractEvidence(text, "BeanCreationException", "UnsatisfiedDependencyException", "No qualifying bean", "Failed to configure"),
                    "常见原因是依赖未声明、Bean 没有被扫描、配置属性缺失、循环依赖或构造器参数无法注入。",
                    "先看最底层 caused by，再检查 @Component/@Service/@MapperScan、pom 依赖和 application.yml。"));
        }

        if (containsAny(lower, "port 8080", "address already in use", "端口")) {
            findings.add(new Finding(
                    Severity.MEDIUM,
                    "Environment",
                    "端口被占用",
                    extractEvidence(text, "address already in use", "Port", "端口"),
                    "应用启动端口已经被其他进程占用。",
                    "关闭占用进程，或修改 server.port。"));
        }

        if (findings.isEmpty()) {
            findings.add(new Finding(
                    Severity.INFO,
                    "Log",
                    "没有命中内置故障规则",
                    shortText(text),
                    "当前日志里没有明显的 401、SQL、Redis、Bean 创建、空指针等常见错误。",
                    "请提供更完整的堆栈、请求 URL、请求方法、响应体和相关源码。"));
        }

        return findings;
    }

    private boolean containsAny(String text, String... keywords) {
        if (text == null) {
            return false;
        }
        for (String keyword : keywords) {
            if (text.contains(keyword)) {
                return true;
            }
        }
        return false;
    }

    private String extractEvidence(String text, String... keywords) {
        String[] lines = text.split("\\R");
        for (String line : lines) {
            for (String keyword : keywords) {
                if (line.contains(keyword)) {
                    return trim(line, 300);
                }
            }
        }
        return shortText(text);
    }

    private String shortText(String text) {
        return trim(text.replaceAll("\\s+", " "), 300);
    }

    private String trim(String text, int limit) {
        if (text == null) {
            return "";
        }
        return text.length() <= limit ? text : text.substring(0, limit) + "...";
    }
}
