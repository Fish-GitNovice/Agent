package com.example.smartops;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartOpsAgentApplication {
    public static void main(String[] args) {
        SpringApplication.run(SmartOpsAgentApplication.class, args);
    }
}
