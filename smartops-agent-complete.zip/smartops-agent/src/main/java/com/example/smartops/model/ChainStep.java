package com.example.smartops.model;

public record ChainStep(
        String layer,
        String className,
        String methodName,
        String evidence,
        int line
) {
}
