package com.example.smartops.service;

import com.example.smartops.model.Finding;
import com.example.smartops.model.Severity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

@Component
public class SqlOptimizeAgent {
    private static final Pattern OFFSET_PATTERN = Pattern.compile("\\blimit\\s+\\d+\\s*,\\s*\\d+|\\boffset\\s+\\d+", Pattern.CASE_INSENSITIVE);

    public List<Finding> analyze(List<String> slowSql) {
        List<Finding> findings = new ArrayList<>();
        if (slowSql == null || slowSql.isEmpty()) {
            findings.add(new Finding(
                    Severity.INFO,
                    "SQL",
                    "未提供慢 SQL",
                    "slowSql 为空",
                    "当前无法判断具体索引和执行计划。",
                    "建议提供 MySQL slow query log、SQL 原文和 EXPLAIN 结果。"));
            return findings;
        }

        for (String sql : slowSql) {
            if (sql == null || sql.isBlank()) {
                continue;
            }
            analyzeOne(sql, findings);
        }
        return findings;
    }

    private void analyzeOne(String sql, List<Finding> findings) {
        String compact = sql.replaceAll("\\s+", " ").trim();
        String lower = compact.toLowerCase(Locale.ROOT);

        if (lower.startsWith("select *")) {
            findings.add(new Finding(
                    Severity.MEDIUM,
                    "SQL",
                    "慢 SQL 使用 SELECT *",
                    compact,
                    "SELECT * 会读取不需要的列，降低索引覆盖概率，数据量大时网络和内存开销也更高。",
                    "只查询页面或业务真正需要的字段，优先让查询走覆盖索引。"));
        }

        if (lower.contains(" like '%")) {
            findings.add(new Finding(
                    Severity.HIGH,
                    "SQL",
                    "LIKE 前置通配符导致索引失效",
                    compact,
                    "LIKE '%keyword' 或 LIKE '%keyword%' 通常无法利用普通 BTree 索引。",
                    "考虑全文索引、倒排索引、搜索引擎，或改成右前缀匹配 like 'keyword%'。"));
        }

        if (OFFSET_PATTERN.matcher(lower).find()) {
            findings.add(new Finding(
                    Severity.MEDIUM,
                    "SQL",
                    "深分页可能导致扫描大量数据",
                    compact,
                    "OFFSET 越大，数据库跳过的数据越多，响应会越来越慢。",
                    "使用基于游标的分页，例如 where id > lastId order by id limit pageSize。"));
        }

        if (lower.contains(" order by ") && !lower.contains(" limit ")) {
            findings.add(new Finding(
                    Severity.MEDIUM,
                    "SQL",
                    "ORDER BY 未限制返回数量",
                    compact,
                    "排序大量数据会产生 filesort 或临时表，消耗 CPU 和内存。",
                    "给排序字段建立合适联合索引，并配合 limit 分页。"));
        }

        if (lower.contains(" or ")) {
            findings.add(new Finding(
                    Severity.LOW,
                    "SQL",
                    "OR 条件可能影响索引选择",
                    compact,
                    "多个 OR 条件可能导致优化器无法稳定选择最佳索引。",
                    "可尝试拆成 UNION ALL，或为高频条件建立联合索引后用 EXPLAIN 验证。"));
        }

        if (!lower.contains(" where ") && lower.startsWith("select")) {
            findings.add(new Finding(
                    Severity.MEDIUM,
                    "SQL",
                    "查询缺少 WHERE 条件",
                    compact,
                    "无条件查询在数据量变大后会扫描整表。",
                    "确认是否需要分页、状态过滤、租户过滤或时间范围过滤。"));
        }
    }
}
