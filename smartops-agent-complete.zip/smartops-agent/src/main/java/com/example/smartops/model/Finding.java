package com.example.smartops.model;

public record Finding(
        Severity severity,
        String category,
        String title,
        String evidence,
        String reason,
        String recommendation
) {
}
