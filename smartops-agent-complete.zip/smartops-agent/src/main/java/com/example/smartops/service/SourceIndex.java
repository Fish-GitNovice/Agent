package com.example.smartops.service;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

public class SourceIndex {
    private final Map<String, JavaClassInfo> classes = new LinkedHashMap<>();

    public void add(JavaClassInfo info) {
        classes.put(info.className(), info);
    }

    public Optional<JavaClassInfo> findClass(String className) {
        return Optional.ofNullable(classes.get(stripGenerics(className)));
    }

    public Collection<JavaClassInfo> allClasses() {
        return classes.values();
    }

    private String stripGenerics(String type) {
        if (type == null) {
            return "";
        }
        int genericIndex = type.indexOf('<');
        if (genericIndex >= 0) {
            return type.substring(0, genericIndex);
        }
        return type.replace("[]", "").trim();
    }
}
