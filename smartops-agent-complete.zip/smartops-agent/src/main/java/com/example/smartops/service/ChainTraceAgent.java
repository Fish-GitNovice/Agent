package com.example.smartops.service;

import com.example.smartops.model.ChainStep;
import com.example.smartops.model.EndpointChain;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class ChainTraceAgent {
    private static final Pattern METHOD_CALL_PATTERN_TEMPLATE = Pattern.compile("__VAR__\\.([a-zA-Z_][A-Za-z0-9_]*)\\s*\\(");

    public List<EndpointChain> trace(SourceIndex index, String focusPath) {
        List<EndpointChain> chains = new ArrayList<>();
        for (JavaClassInfo clazz : index.allClasses()) {
            if (!isController(clazz)) {
                continue;
            }
            String basePath = MappingParser.classLevelPath(clazz.annotations());
            for (JavaMethodInfo method : clazz.methods().values()) {
                MappingParser.parse(method.annotations()).ifPresent(mapping -> {
                    String path = MappingParser.joinPath(basePath, mapping.path());
                    if (focusPath != null && !focusPath.isBlank() && !path.contains(focusPath)) {
                        return;
                    }
                    List<ChainStep> steps = new ArrayList<>();
                    steps.add(new ChainStep("Controller", clazz.className(), method.name(),
                            "接口入口：" + mapping.method() + " " + path, method.startLine()));
                    Set<String> visited = new HashSet<>();
                    traceMethodBody(index, clazz, method, steps, visited, 0);
                    chains.add(new EndpointChain(mapping.method(), path, clazz.className(), method.name(), steps));
                });
            }
        }
        return chains;
    }

    private boolean isController(JavaClassInfo clazz) {
        return clazz.annotations().contains("@RestController") || clazz.annotations().contains("@Controller");
    }

    private void traceMethodBody(SourceIndex index,
                                 JavaClassInfo owner,
                                 JavaMethodInfo method,
                                 List<ChainStep> steps,
                                 Set<String> visited,
                                 int depth) {
        if (depth > 3 || method == null || method.body() == null) {
            return;
        }
        String visitKey = owner.className() + "#" + method.name();
        if (!visited.add(visitKey)) {
            return;
        }
        String body = method.body();
        detectSpecialOperations(owner, method, steps);

        for (Map.Entry<String, String> field : owner.fields().entrySet()) {
            String variableName = field.getKey();
            String fieldType = field.getValue();
            Pattern callPattern = Pattern.compile(Pattern.quote(variableName) + "\\.([a-zA-Z_][A-Za-z0-9_]*)\\s*\\(");
            Matcher callMatcher = callPattern.matcher(body);
            while (callMatcher.find()) {
                String calledMethod = callMatcher.group(1);
                String layer = layerOf(fieldType);
                String evidence = variableName + "." + calledMethod + "(...)";
                int line = method.startLine() + countLines(body.substring(0, callMatcher.start())) - 1;
                steps.add(new ChainStep(layer, fieldType, calledMethod, evidence, line));

                index.findClass(fieldType).ifPresent(targetClass -> {
                    JavaMethodInfo targetMethod = targetClass.methods().get(calledMethod);
                    if (targetMethod != null && shouldGoDeeper(layer)) {
                        traceMethodBody(index, targetClass, targetMethod, steps, visited, depth + 1);
                    }
                });
            }
        }
    }

    private void detectSpecialOperations(JavaClassInfo owner, JavaMethodInfo method, List<ChainStep> steps) {
        String body = method.body();
        if (containsAny(body, "RedisTemplate", "StringRedisTemplate", "redisTemplate", "stringRedisTemplate", "@Cacheable", "@CacheEvict")) {
            steps.add(new ChainStep("Cache", owner.className(), method.name(), "发现 Redis / Spring Cache 相关操作", method.startLine()));
        }
        if (containsAny(body, "RestTemplate", "WebClient", "HttpClient", "FeignClient", "OkHttp")) {
            steps.add(new ChainStep("External API", owner.className(), method.name(), "发现第三方 HTTP 调用", method.startLine()));
        }
        if (containsAny(body, "SecurityContextHolder", "Authentication", "Jwt", "Claims", "Authorization")) {
            steps.add(new ChainStep("Security", owner.className(), method.name(), "发现鉴权 / JWT 上下文读取", method.startLine()));
        }
        if (containsAny(body, "@Transactional", ".save(", ".update(", ".delete(", ".insert(")) {
            steps.add(new ChainStep("Transaction/Write", owner.className(), method.name(), "发现事务或写操作", method.startLine()));
        }
    }

    private boolean containsAny(String text, String... keywords) {
        if (text == null) {
            return false;
        }
        for (String keyword : keywords) {
            if (text.contains(keyword)) {
                return true;
            }
        }
        return false;
    }

    private boolean shouldGoDeeper(String layer) {
        return layer.equals("Service") || layer.equals("Security") || layer.equals("Cache") || layer.equals("Component");
    }

    private String layerOf(String type) {
        if (type == null) {
            return "Component";
        }
        if (type.endsWith("Controller")) {
            return "Controller";
        }
        if (type.endsWith("Service") || type.endsWith("ServiceImpl")) {
            return "Service";
        }
        if (type.endsWith("Repository") || type.endsWith("Mapper") || type.endsWith("Dao")) {
            return "Persistence";
        }
        if (type.contains("Redis") || type.contains("Cache")) {
            return "Cache";
        }
        if (type.contains("Jwt") || type.contains("Security") || type.contains("PasswordEncoder")) {
            return "Security";
        }
        return "Component";
    }

    private int countLines(String text) {
        int count = 1;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '\n') {
                count++;
            }
        }
        return count;
    }
}
