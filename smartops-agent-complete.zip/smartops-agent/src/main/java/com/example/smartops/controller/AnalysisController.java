package com.example.smartops.controller;

import com.example.smartops.model.AnalysisRequest;
import com.example.smartops.model.AnalysisResponse;
import com.example.smartops.model.ProjectFile;
import com.example.smartops.service.AnalysisOrchestrator;
import com.example.smartops.service.ProjectZipService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/analysis")
@CrossOrigin
public class AnalysisController {
    private final AnalysisOrchestrator orchestrator;
    private final ProjectZipService projectZipService;

    public AnalysisController(AnalysisOrchestrator orchestrator, ProjectZipService projectZipService) {
        this.orchestrator = orchestrator;
        this.projectZipService = projectZipService;
    }

    @GetMapping("/health")
    public Map<String, Object> health() {
        return Map.of(
                "status", "UP",
                "service", "SmartOps Agent",
                "features", List.of("chain-trace", "log-diagnosis", "security-diagnosis", "sql-optimization", "repair-suggestion")
        );
    }

    @PostMapping("/analyze-text")
    public AnalysisResponse analyzeText(@RequestBody AnalysisRequest request) {
        return orchestrator.analyze(request);
    }

    @PostMapping(value = "/upload-zip", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public AnalysisResponse analyzeZip(@RequestParam("file") MultipartFile file,
                                       @RequestParam(value = "projectName", required = false) String projectName,
                                       @RequestParam(value = "logText", required = false) String logText,
                                       @RequestParam(value = "slowSql", required = false) String slowSql,
                                       @RequestParam(value = "focusPath", required = false) String focusPath) throws IOException {
        List<ProjectFile> files = projectZipService.readSupportedFiles(file);
        List<String> slowSqlList = slowSql == null || slowSql.isBlank()
                ? List.of()
                : Arrays.stream(slowSql.split(";"))
                .map(String::trim)
                .filter(s -> !s.isBlank())
                .toList();
        AnalysisRequest request = new AnalysisRequest(
                projectName == null || projectName.isBlank() ? file.getOriginalFilename() : projectName,
                files,
                logText,
                slowSqlList,
                focusPath
        );
        return orchestrator.analyze(request);
    }
}
