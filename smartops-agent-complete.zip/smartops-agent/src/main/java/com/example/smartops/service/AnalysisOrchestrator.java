package com.example.smartops.service;

import com.example.smartops.model.AnalysisRequest;
import com.example.smartops.model.AnalysisResponse;
import com.example.smartops.model.EndpointChain;
import com.example.smartops.model.Finding;
import com.example.smartops.model.ProjectFile;
import com.example.smartops.model.Suggestion;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AnalysisOrchestrator {
    private final SourceCodeScanner sourceCodeScanner;
    private final ChainTraceAgent chainTraceAgent;
    private final LogAnalysisAgent logAnalysisAgent;
    private final SecurityDiagnosisAgent securityDiagnosisAgent;
    private final SqlOptimizeAgent sqlOptimizeAgent;
    private final RepairSuggestionAgent repairSuggestionAgent;
    private final ReportRenderer reportRenderer;

    public AnalysisOrchestrator(SourceCodeScanner sourceCodeScanner,
                                ChainTraceAgent chainTraceAgent,
                                LogAnalysisAgent logAnalysisAgent,
                                SecurityDiagnosisAgent securityDiagnosisAgent,
                                SqlOptimizeAgent sqlOptimizeAgent,
                                RepairSuggestionAgent repairSuggestionAgent,
                                ReportRenderer reportRenderer) {
        this.sourceCodeScanner = sourceCodeScanner;
        this.chainTraceAgent = chainTraceAgent;
        this.logAnalysisAgent = logAnalysisAgent;
        this.securityDiagnosisAgent = securityDiagnosisAgent;
        this.sqlOptimizeAgent = sqlOptimizeAgent;
        this.repairSuggestionAgent = repairSuggestionAgent;
        this.reportRenderer = reportRenderer;
    }

    public AnalysisResponse analyze(AnalysisRequest request) {
        List<ProjectFile> files = request == null ? List.of() : nullToEmpty(request.sourceFiles());
        String projectName = request == null ? "未命名项目" : request.projectName();
        String logText = request == null ? "" : request.logText();
        List<String> slowSql = request == null ? List.of() : nullToEmpty(request.slowSql());
        String focusPath = request == null ? "" : request.focusPath();

        SourceIndex index = sourceCodeScanner.buildIndex(files);
        List<EndpointChain> chains = chainTraceAgent.trace(index, focusPath);

        List<Finding> findings = new ArrayList<>();
        findings.addAll(logAnalysisAgent.analyze(logText));
        findings.addAll(securityDiagnosisAgent.analyze(files));
        findings.addAll(sqlOptimizeAgent.analyze(slowSql));

        List<Suggestion> suggestions = repairSuggestionAgent.generate(findings);
        String report = reportRenderer.render(projectName, chains, findings, suggestions);
        return new AnalysisResponse(projectName, chains, findings, suggestions, report);
    }

    private <T> List<T> nullToEmpty(List<T> input) {
        return input == null ? List.of() : input;
    }
}
