package com.example.smartops.service;

import java.util.List;

public record JavaMethodInfo(
        String name,
        String annotations,
        String body,
        int startLine,
        List<String> parameters
) {
}
