package com.example.smartops.service;

import com.example.smartops.model.ProjectFile;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class SourceCodeScanner {
    private static final Pattern PACKAGE_PATTERN = Pattern.compile("package\\s+([a-zA-Z0-9_.]+)\\s*;");
    private static final Pattern CLASS_PATTERN = Pattern.compile("((?:@[A-Za-z0-9_]+(?:\\([^)]*\\))?\\s*)*)\\s*(?:public\\s+)?(?:class|record|interface)\\s+([A-Z][A-Za-z0-9_]*)");
    private static final Pattern FIELD_PATTERN = Pattern.compile("(?:private|protected|public)\\s+(?:final\\s+)?([A-Za-z0-9_<>?,\\s]+)\\s+([a-z][A-Za-z0-9_]*)\\s*(?:=|;)");
    private static final Pattern METHOD_PATTERN = Pattern.compile("((?:@[A-Za-z0-9_]+(?:\\([^)]*\\))?\\s*)*)\\s*(?:public|private|protected)\\s+[A-Za-z0-9_<>, ?\\[\\]]+\\s+([a-zA-Z_][A-Za-z0-9_]*)\\s*\\(([^)]*)\\)\\s*(?:throws\\s+[^{]+)?\\{");

    public SourceIndex buildIndex(List<ProjectFile> files) {
        SourceIndex index = new SourceIndex();
        if (files == null) {
            return index;
        }
        for (ProjectFile file : files) {
            if (file == null || file.path() == null || file.content() == null || !file.path().endsWith(".java")) {
                continue;
            }
            parseJavaFile(file).ifPresent(index::add);
        }
        return index;
    }

    private Optional<JavaClassInfo> parseJavaFile(ProjectFile file) {
        String content = removeBlockComments(file.content());
        Matcher classMatcher = CLASS_PATTERN.matcher(content);
        if (!classMatcher.find()) {
            return Optional.empty();
        }
        String packageName = matchFirst(PACKAGE_PATTERN, content);
        String annotations = classMatcher.group(1) == null ? "" : classMatcher.group(1);
        String className = classMatcher.group(2);
        JavaClassInfo info = new JavaClassInfo(file.path(), packageName, className, content, annotations);
        parseFields(content, info);
        parseMethods(content, info);
        return Optional.of(info);
    }

    private void parseFields(String content, JavaClassInfo info) {
        Matcher matcher = FIELD_PATTERN.matcher(content);
        while (matcher.find()) {
            String type = normalizeType(matcher.group(1));
            String name = matcher.group(2);
            if (!type.contains(" static ")) {
                info.fields().put(name, type);
            }
        }
    }

    private void parseMethods(String content, JavaClassInfo info) {
        Matcher matcher = METHOD_PATTERN.matcher(content);
        while (matcher.find()) {
            String annotations = matcher.group(1) == null ? "" : matcher.group(1);
            String name = matcher.group(2);
            String params = matcher.group(3) == null ? "" : matcher.group(3);
            int bodyStart = matcher.end() - 1;
            int bodyEnd = findMatchingBrace(content, bodyStart);
            if (bodyEnd <= bodyStart) {
                continue;
            }
            String body = content.substring(bodyStart, bodyEnd + 1);
            int line = lineNumber(content, matcher.start());
            info.methods().put(name, new JavaMethodInfo(name, annotations, body, line, parseParameters(params)));
        }
    }

    private int findMatchingBrace(String text, int openBraceIndex) {
        int depth = 0;
        boolean inString = false;
        boolean inChar = false;
        boolean escaped = false;
        for (int i = openBraceIndex; i < text.length(); i++) {
            char c = text.charAt(i);
            if (escaped) {
                escaped = false;
                continue;
            }
            if (c == '\\') {
                escaped = true;
                continue;
            }
            if (c == '"' && !inChar) {
                inString = !inString;
                continue;
            }
            if (c == '\'' && !inString) {
                inChar = !inChar;
                continue;
            }
            if (inString || inChar) {
                continue;
            }
            if (c == '{') {
                depth++;
            } else if (c == '}') {
                depth--;
                if (depth == 0) {
                    return i;
                }
            }
        }
        return -1;
    }

    private String matchFirst(Pattern pattern, String content) {
        Matcher matcher = pattern.matcher(content);
        return matcher.find() ? matcher.group(1) : "";
    }

    private String removeBlockComments(String content) {
        return content.replaceAll("(?s)/\\*.*?\\*/", "");
    }

    private String normalizeType(String raw) {
        String type = raw.replaceAll("\\s+", " ").trim();
        if (type.contains(" ")) {
            String[] parts = type.split(" ");
            return parts[parts.length - 1].trim();
        }
        return type;
    }

    private List<String> parseParameters(String params) {
        if (params.isBlank()) {
            return List.of();
        }
        List<String> result = new ArrayList<>();
        Arrays.stream(params.split(","))
                .map(String::trim)
                .filter(s -> !s.isBlank())
                .forEach(result::add);
        return result;
    }

    public int lineNumber(String content, int index) {
        int line = 1;
        for (int i = 0; i < Math.min(index, content.length()); i++) {
            if (content.charAt(i) == '\n') {
                line++;
            }
        }
        return line;
    }
}
