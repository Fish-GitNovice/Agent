package com.example.smartops.model;

public record ProjectFile(
        String path,
        String content
) {
}
