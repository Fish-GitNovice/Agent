package com.example.smartops.model;

import java.util.List;

public record AnalysisRequest(
        String projectName,
        List<ProjectFile> sourceFiles,
        String logText,
        List<String> slowSql,
        String focusPath
) {
}
