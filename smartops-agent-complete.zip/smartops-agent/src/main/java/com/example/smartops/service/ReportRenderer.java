package com.example.smartops.service;

import com.example.smartops.model.AnalysisResponse;
import com.example.smartops.model.ChainStep;
import com.example.smartops.model.EndpointChain;
import com.example.smartops.model.Finding;
import com.example.smartops.model.Severity;
import com.example.smartops.model.Suggestion;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class ReportRenderer {
    public String render(String projectName,
                         List<EndpointChain> chains,
                         List<Finding> findings,
                         List<Suggestion> suggestions) {
        StringBuilder md = new StringBuilder();
        md.append("# SmartOps Agent 分析报告\n\n");
        md.append("项目：").append(projectName == null || projectName.isBlank() ? "未命名项目" : projectName).append("\n\n");

        Map<Severity, Long> severityCount = findings.stream()
                .collect(Collectors.groupingBy(Finding::severity, Collectors.counting()));
        md.append("## 1. 总览\n\n");
        md.append("- 扫描到接口链路：").append(chains.size()).append(" 条\n");
        md.append("- 问题总数：").append(findings.size()).append(" 个\n");
        for (Severity severity : Severity.values()) {
            long count = severityCount.getOrDefault(severity, 0L);
            if (count > 0) {
                md.append("- ").append(severity).append("：").append(count).append(" 个\n");
            }
        }

        md.append("\n## 2. 接口业务链路\n\n");
        if (chains.isEmpty()) {
            md.append("未扫描到 Controller 接口。请确认源码中是否存在 @RestController / @Controller 和 @GetMapping / @PostMapping。\n");
        } else {
            for (EndpointChain chain : chains) {
                md.append("### ").append(chain.httpMethod()).append(" ").append(chain.path()).append("\n\n");
                md.append("入口：").append(chain.controllerClass()).append("#").append(chain.controllerMethod()).append("\n\n");
                int i = 1;
                for (ChainStep step : chain.steps()) {
                    md.append(i++).append(". **").append(step.layer()).append("** ")
                            .append(step.className()).append("#").append(step.methodName())
                            .append("  ");
                    if (step.line() > 0) {
                        md.append("第 ").append(step.line()).append(" 行  ");
                    }
                    md.append("\n   - 证据：").append(nullToEmpty(step.evidence())).append("\n");
                }
                md.append("\n");
            }
        }

        md.append("## 3. 发现的问题\n\n");
        if (findings.isEmpty()) {
            md.append("没有发现明显问题。\n");
        } else {
            findings.stream()
                    .sorted(Comparator.comparing(Finding::severity).reversed())
                    .forEach(finding -> {
                        md.append("### [").append(finding.severity()).append("] ").append(finding.title()).append("\n\n");
                        md.append("- 分类：").append(finding.category()).append("\n");
                        md.append("- 证据：").append(nullToEmpty(finding.evidence())).append("\n");
                        md.append("- 原因：").append(nullToEmpty(finding.reason())).append("\n");
                        md.append("- 建议：").append(nullToEmpty(finding.recommendation())).append("\n\n");
                    });
        }

        md.append("## 4. 修复建议\n\n");
        if (suggestions.isEmpty()) {
            md.append("暂无修复建议。\n");
        } else {
            for (Suggestion suggestion : suggestions) {
                md.append("### ").append(suggestion.title()).append("\n\n");
                md.append("- 目标：").append(nullToEmpty(suggestion.target())).append("\n");
                md.append("- 动作：").append(nullToEmpty(suggestion.action())).append("\n");
                if (suggestion.codeSnippet() != null && !suggestion.codeSnippet().isBlank()) {
                    md.append("\n```java\n").append(suggestion.codeSnippet()).append("\n```\n");
                }
                md.append("\n");
            }
        }

        md.append("## 5. 下一步\n\n");
        md.append("建议按这个顺序处理：先修 CRITICAL/HIGH 安全和启动问题，再修 SQL/Redis 问题，最后补测试用例和接口文档。\n");
        return md.toString();
    }

    private String nullToEmpty(String value) {
        return value == null ? "" : value;
    }
}
