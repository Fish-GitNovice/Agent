package com.example.smartops.service;

import com.example.smartops.model.ProjectFile;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@Service
public class ProjectZipService {
    private static final int MAX_FILE_SIZE = 1024 * 1024;
    private static final int MAX_TOTAL_FILES = 800;
    private static final Set<String> SUPPORTED_EXTENSIONS = Set.of(
            ".java", ".xml", ".yml", ".yaml", ".properties", ".sql", ".md"
    );

    public List<ProjectFile> readSupportedFiles(MultipartFile multipartFile) throws IOException {
        List<ProjectFile> files = new ArrayList<>();
        try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(multipartFile.getInputStream()))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null && files.size() < MAX_TOTAL_FILES) {
                if (entry.isDirectory() || shouldSkip(entry.getName())) {
                    continue;
                }
                byte[] bytes = zis.readNBytes(MAX_FILE_SIZE + 1);
                if (bytes.length > MAX_FILE_SIZE) {
                    continue;
                }
                files.add(new ProjectFile(entry.getName(), new String(bytes, StandardCharsets.UTF_8)));
            }
        }
        return files;
    }

    private boolean shouldSkip(String name) {
        String lower = name.toLowerCase();
        if (lower.contains("/target/") || lower.contains("/.git/") || lower.contains("/node_modules/")) {
            return true;
        }
        for (String ext : SUPPORTED_EXTENSIONS) {
            if (lower.endsWith(ext)) {
                return false;
            }
        }
        return true;
    }
}
