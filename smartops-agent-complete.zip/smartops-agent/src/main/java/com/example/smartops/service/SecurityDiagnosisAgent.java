package com.example.smartops.service;

import com.example.smartops.model.Finding;
import com.example.smartops.model.ProjectFile;
import com.example.smartops.model.Severity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Component
public class SecurityDiagnosisAgent {
    public List<Finding> analyze(List<ProjectFile> files) {
        List<Finding> findings = new ArrayList<>();
        String all = join(files);
        String lower = all.toLowerCase(Locale.ROOT);

        if (all.isBlank()) {
            return findings;
        }

        if (all.contains("spring-boot-starter-security") || all.contains("SecurityFilterChain") || all.contains("Jwt")) {
            if (!all.contains("SecurityFilterChain") && !all.contains("WebSecurityConfigurerAdapter")) {
                findings.add(new Finding(
                        Severity.HIGH,
                        "Security",
                        "引入了安全能力但没有发现明确的 SecurityFilterChain 配置",
                        "存在 spring security / jwt 相关代码，但未扫描到 SecurityFilterChain",
                        "Spring Security 默认会保护所有接口，如果没有配置放行规则，登录、注册、静态资源可能直接 401。",
                        "补充 SecurityConfig，明确配置 permitAll、authenticated、JWT Filter、异常处理和 CORS。"));
            }

            if (all.contains("Jwt") && !all.contains("SessionCreationPolicy.STATELESS")) {
                findings.add(new Finding(
                        Severity.MEDIUM,
                        "Security",
                        "JWT 项目建议配置无状态会话",
                        "发现 Jwt 相关代码，但没有发现 SessionCreationPolicy.STATELESS",
                        "JWT 通常不依赖服务端 Session，如果保留 Session，容易让鉴权行为变得混乱。",
                        "在 SecurityFilterChain 中配置 sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))。"));
            }

            if (all.contains("Jwt") && !all.contains("Bearer")) {
                findings.add(new Finding(
                        Severity.MEDIUM,
                        "Security",
                        "JWT 请求头格式可能没有统一",
                        "发现 Jwt 相关代码，但未发现 Bearer 处理逻辑",
                        "前端和后端如果没有统一 Authorization: Bearer <token>，就容易出现 401。",
                        "在 JWT Filter 中统一解析 Bearer 前缀，并在前端请求拦截器中统一添加。"));
            }

            if (!all.contains("PasswordEncoder") && !all.contains("BCrypt") && !all.contains("Argon2")) {
                findings.add(new Finding(
                        Severity.CRITICAL,
                        "Security",
                        "没有发现密码加密组件",
                        "未扫描到 PasswordEncoder / BCrypt / Argon2",
                        "登录系统如果明文保存或直接比较密码，安全风险很高，也不符合真实项目要求。",
                        "使用 BCryptPasswordEncoder 或 Argon2PasswordEncoder，并在登录时使用 matches(raw, encoded)。"));
            }

            if (all.contains("PasswordEncoder") && lower.contains("==") && lower.contains("password")) {
                findings.add(new Finding(
                        Severity.HIGH,
                        "Security",
                        "密码比较方式疑似不正确",
                        "源码中同时出现 PasswordEncoder、password 和 ==",
                        "加密后的密码不能用 == 或 equals 直接和明文比较，必须使用 passwordEncoder.matches。",
                        "把密码校验统一改成 passwordEncoder.matches(rawPassword, dbPassword)。"));
            }

            if (all.contains("csrf().disable") || all.contains("csrf(csrf -> csrf.disable())")) {
                findings.add(new Finding(
                        Severity.INFO,
                        "Security",
                        "CSRF 已关闭，需要确认项目类型",
                        "发现 csrf disable 配置",
                        "前后端分离 + JWT 项目通常可以关闭 CSRF；如果是表单 Session 项目，则不建议随便关闭。",
                        "确认当前系统是否完全使用 JWT。若使用 Cookie/Session 登录，需要重新评估 CSRF。"));
            }

            if (all.contains("permitAll") && !containsAny(all, "/login", "/auth", "/register")) {
                findings.add(new Finding(
                        Severity.MEDIUM,
                        "Security",
                        "放行规则可能不完整",
                        "发现 permitAll，但未明显发现 /login、/auth 或 /register",
                        "登录接口如果没有放行，用户还没有 token 就无法登录。",
                        "检查 SecurityConfig，把登录、注册、验证码、静态资源等接口放行。"));
            }

            if (all.contains("logout") && all.contains("Jwt") && !containsAny(all, "blacklist", "Redis", "redisTemplate", "StringRedisTemplate")) {
                findings.add(new Finding(
                        Severity.LOW,
                        "Security",
                        "JWT 退出登录可能只是前端删除 token",
                        "发现 logout + Jwt，但未发现 Redis/黑名单相关逻辑",
                        "纯 JWT 默认无法服务端立即失效，退出登录通常只是前端删除 token。真实项目可以加入 token 黑名单。",
                        "如果需要更强安全性，logout 时把 token 写入 Redis 黑名单，过期时间设置为 JWT 剩余有效期。"));
            }
        }

        return findings;
    }

    private String join(List<ProjectFile> files) {
        if (files == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (ProjectFile file : files) {
            if (file != null && file.content() != null) {
                sb.append('\n').append(file.path()).append('\n').append(file.content());
            }
        }
        return sb.toString();
    }

    private boolean containsAny(String text, String... keywords) {
        for (String keyword : keywords) {
            if (text.contains(keyword)) {
                return true;
            }
        }
        return false;
    }
}
