package com.example.smartops.model;

public record Suggestion(
        String title,
        String target,
        String action,
        String codeSnippet
) {
}
