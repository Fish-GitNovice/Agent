package com.example.smartops.service;

import com.example.smartops.model.Finding;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class LogAnalysisAgentTest {
    private final LogAnalysisAgent agent = new LogAnalysisAgent();

    @Test
    void shouldDetectUnauthorized() {
        List<Finding> findings = agent.analyze("HTTP 401 Unauthorized: Full authentication is required");
        assertThat(findings).anyMatch(f -> f.title().contains("401"));
    }

    @Test
    void shouldDetectRedisError() {
        List<Finding> findings = agent.analyze("RedisConnectionFailureException: Unable to connect to Redis server");
        assertThat(findings).anyMatch(f -> f.category().equals("Redis"));
    }
}
