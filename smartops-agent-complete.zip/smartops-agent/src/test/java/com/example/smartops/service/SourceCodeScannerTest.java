package com.example.smartops.service;

import com.example.smartops.model.EndpointChain;
import com.example.smartops.model.ProjectFile;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class SourceCodeScannerTest {
    @Test
    void shouldTraceControllerToService() {
        SourceCodeScanner scanner = new SourceCodeScanner();
        ChainTraceAgent chainTraceAgent = new ChainTraceAgent();
        List<ProjectFile> files = List.of(
                new ProjectFile("AuthController.java", """
                        package demo;
                        import org.springframework.web.bind.annotation.*;
                        @RestController
                        @RequestMapping("/api/auth")
                        public class AuthController {
                            private final AuthService authService;
                            public AuthController(AuthService authService) { this.authService = authService; }
                            @PostMapping("/login")
                            public String login() { return authService.login(); }
                        }
                        """),
                new ProjectFile("AuthService.java", """
                        package demo;
                        public class AuthService {
                            private final UserMapper userMapper;
                            public AuthService(UserMapper userMapper) { this.userMapper = userMapper; }
                            public String login() { userMapper.selectByUsername(); return "token"; }
                        }
                        """));
        SourceIndex index = scanner.buildIndex(files);
        List<EndpointChain> chains = chainTraceAgent.trace(index, "");
        assertThat(chains).hasSize(1);
        assertThat(chains.get(0).path()).isEqualTo("/api/auth/login");
        assertThat(chains.get(0).steps()).anyMatch(s -> s.className().equals("AuthService"));
    }
}
