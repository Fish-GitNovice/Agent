# SmartOps Agent 架构设计

## 核心目标

SmartOps Agent 解决的是 Java 后端开发中最耗时间的排查问题：

1. 不知道一次请求从 Controller 到数据库经过哪些类。
2. 看到 401、SQL 报错、Redis 失败、NPE 后不知道从哪里开始查。
3. 写了 Spring Security / JWT，但不知道配置是否完整。
4. SQL 慢，但不会从执行计划、索引、分页角度分析。

## 总体流程

```mermaid
flowchart LR
    A[上传项目 ZIP / 粘贴日志 / 慢 SQL] --> B[ProjectZipService]
    B --> C[SourceCodeScanner]
    C --> D[SourceIndex]
    D --> E[ChainTraceAgent]
    A --> F[LogAnalysisAgent]
    A --> G[SqlOptimizeAgent]
    D --> H[SecurityDiagnosisAgent]
    E --> I[AnalysisOrchestrator]
    F --> I
    G --> I
    H --> I
    I --> J[RepairSuggestionAgent]
    J --> K[ReportRenderer]
    K --> L[Markdown 报告 / JSON 响应]
```

## 为什么这个项目有含金量

普通项目多数是 CRUD，而这个项目覆盖了真实后端开发里的工程能力：

- 源码静态分析
- 接口链路追踪
- 日志诊断
- Spring Security / JWT 安全检查
- 慢 SQL 优化
- Redis 故障排查
- 自动生成修复建议
- 报告生成

它可以作为“AI + Java 后端 + DevOps + 代码分析”的综合项目。

## 当前 MVP 的边界

当前版本使用轻量正则解析源码，优点是无额外依赖，启动简单；缺点是遇到复杂语法、泛型、链式调用时准确率不如 AST。

后续推荐升级为：

- JavaParser：做 AST 级别源码分析
- OpenTelemetry：采集真实链路
- MySQL EXPLAIN：读取真实执行计划
- Git Patch：自动生成修复 diff
- LLM Provider：把规则诊断升级为自然语言推理
